
using System;

namespace xbmcontrolevo
{
	
	
	public class Configuration
	{
		
		public Configuration()
		{
		}
	}
}
